package BrowserStack.BrowserStackArtifact;

import org.openqa.selenium.MutableCapabilities;
import org.testng.annotations.DataProvider;

public class BrowserStackCapabilities {

    @DataProvider(name = "browserStackDataProvider", parallel = true)
    public static Object[][] browserStackDataProvider() {
        return new Object[][]{
            // Desktop Chrome
            {new MutableCapabilities() {{
                setCapability("browserName", "Chrome");
                setCapability("browserVersion", "latest");
                setCapability("os", "Windows");
                setCapability("osVersion", "10");
            }}},
            // Desktop Safari
            {new MutableCapabilities() {{
                setCapability("browserName", "Safari");
                setCapability("browserVersion", "latest");
                setCapability("os", "OS X");
                setCapability("osVersion", "Monterey");
            }}},
            // Desktop Edge
            {new MutableCapabilities() {{
                setCapability("browserName", "Edge");
                setCapability("browserVersion", "latest");
                setCapability("os", "Windows");
                setCapability("osVersion", "11");
            }}},
            // Mobile iPhone
            {new MutableCapabilities() {{
                setCapability("browserName", "iPhone");
                setCapability("device", "iPhone 14");
                setCapability("realMobile", "true");
                setCapability("osVersion", "16");
            }}},
            // Mobile Android
            {new MutableCapabilities() {{
                setCapability("browserName", "Android");
                setCapability("device", "Samsung Galaxy S22");
                setCapability("realMobile", "true");
                setCapability("osVersion", "12.0");
            }}}
        };
    }
}

