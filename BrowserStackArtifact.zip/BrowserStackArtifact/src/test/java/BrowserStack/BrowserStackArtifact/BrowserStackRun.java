package BrowserStack.BrowserStackArtifact;

import org.json.JSONObject;
import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.io.*;
import java.net.*;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.*;
import java.time.Duration;
import java.util.*;

public class BrowserStackRun {

    private static final String BROWSERSTACK_USERNAME = "ankit_sGa0Lq";
    private static final String BROWSERSTACK_ACCESS_KEY = "Bxc5TSQ8RNk57BbcL9Rs"; 
    private static final String HUB_URL = "https://" + BROWSERSTACK_USERNAME + ":" + BROWSERSTACK_ACCESS_KEY + "@hub-cloud.browserstack.com/wd/hub";

	public static void main(String[] args) throws Exception {
    
		// Configure Browser stack headless mode run
       ChromeOptions options = new ChromeOptions();
       Map<String, Object> bstackOptions= new HashMap<>();
       bstackOptions.put("os", "Windows");
       bstackOptions.put("osVersion", "10");
       bstackOptions.put("sessionName", "BrowserStack Run");
       bstackOptions.put("seleniumVersion", "4.33.0");
       
       options.setCapability("bstack:options", bstackOptions);
       
       URI uri=new URI(HUB_URL);
       WebDriver driver=new RemoteWebDriver(uri.toURL(), options);
       
       // Open the web application
        driver.get("https://elpais.com/");
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        
        // Handle the cookies popup
        WebElement element=driver.findElement(By.xpath("//button[@id='didomi-notice-agree-button']"));
        element.click();
        
        // Navigate to Opinion section
        driver.findElement(By.xpath("//a[contains(text(),'Internacional')]/following-sibling::a")).click();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div/article")));
       
        // Fetch the first 3 articles
        List<WebElement> articles = driver.findElements(By.xpath("//div/article"));
        int count = Math.min(3, articles.size()); // Sets count to the maximum number of articles you want to process
        System.out.println(count);
        List<String> spanishTitles = new ArrayList<>();
        List<String> englishTitles = new ArrayList<>();

        for (int i = 0; i < count; i++) {
            WebElement article = articles.get(i);
            // Extract title
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
            String title = article.findElement(By.cssSelector("h2")).getText();
            spanishTitles.add(title);
            System.out.println("Title: " + title);

            // Extract article URL
            String articleUrl = article.findElement(By.cssSelector("a")).getAttribute("href");
            System.out.println(articleUrl);
            
            // Go to article page
            driver.navigate().to(articleUrl);
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));        
           JavascriptExecutor js = (JavascriptExecutor) driver;
           js.executeScript("window.scrollBy(0, 300);"); // scroll to view
           driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
           WebElement articleContent=driver.findElement(By.xpath("//*[@id='main-content']/div/div/article/p"));
          
           driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
            // Extract content (may need to adjust selector)
            String content = articleContent.getText();
            System.out.println("Content: " + content);

            // Download cover image if available
            try {
                WebElement img = driver.findElement(By.xpath("//*[@id='main-content']/div/div/article/figure/a/img"));
                String imgUrl = img.getAttribute("src");
                downloadImage(imgUrl, "cover_image_" + i + ".jpg");
                System.out.println("Image Name: cover_image_" + i + ".jpg");
            } catch (NoSuchElementException e) {
                System.out.println("No image exist");
            }

            // Return to opinion section
            driver.navigate().back();
            js.executeScript("window.scrollBy(0, 300);");
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("article")));
        }
    
        // Translate titles
        for (String title : spanishTitles) {
            String translated = translateText(title, "es", "en");
            englishTitles.add(translated);
            System.out.println("Translated Title: " + translated);
        }

        // Analyze repeated words
        Map<String, Integer> wordCount = new HashMap<>(); // Store each word as key and its frequency as the value
        for (String header : englishTitles) {
            String[] words = header.toLowerCase().replaceAll("[^a-z ]", "").split("\\s+");//convert to lowercase, removes all characters except lower case and spaces, split the string in to words using whitespace
            for (String word : words) {
                if (word.length() > 2) { // Ignore very short words like an, of etc.
                    wordCount.put(word, wordCount.getOrDefault(word, 0) + 1);
                }
            }
        }
        System.out.println("Repeated words (more than twice):");
        for (Map.Entry<String, Integer> entry : wordCount.entrySet()) {
            if (entry.getValue() > 2) {
                System.out.println(entry.getKey() + ": " + entry.getValue());
            }
        }
        driver.quit();
    	}

    // Download image from URL
		private static void downloadImage(String url, String fileName) throws IOException, InterruptedException {
	    HttpClient client = HttpClient.newHttpClient();
	    HttpRequest request = HttpRequest.newBuilder()
	            .uri(URI.create(url))
	            .build();

	    HttpResponse<byte[]> response = client.send(request, HttpResponse.BodyHandlers.ofByteArray());

	    if (response.statusCode() == 200) {
	        Path path = Paths.get(fileName);
	        java.nio.file.Files.write(path, response.body());
	        System.out.println("Image downloaded: " + fileName);
	    } else {
	        System.out.println("Failed to download image: HTTP " + response.statusCode());
	    }

    }
 
    // Translate text using Google Translate API
    private static String translateText(String text, String sourceLang, String targetLang) throws IOException, InterruptedException {

    	//Build the JSON request body
    	JSONObject body=new JSONObject();
        body.put("from", sourceLang);
        body.put("to", targetLang);
        body.put("text", text);
        
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create("https://rapid-translate-multi-traduction.p.rapidapi.com/t"))
            .header("content-type", "application/json")
            .header("X-RapidAPI-Key", "3011e7f4f2msh99374f7dfcf6bacp145bb1jsn5764cab49f78")
            .header("X-RapidAPI-Host", "rapid-translate-multi-traduction.p.rapidapi.com")
            .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
            .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        System.out.println("Response Body: " + response.body());
        
        if (response.statusCode() == 200) {
            JSONObject json = new JSONObject(response.body());
            // The translated text is in the "result" field
            return json.getString("result");
        } else {
            throw new RuntimeException("Translation failed: HTTP " + response.statusCode() + " - " + response.body());
        }

    }
}
	

