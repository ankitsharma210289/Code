package BrowserStack.BrowserStackArtifact;

import org.json.JSONObject;
import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.openqa.selenium.support.ui.ExpectedConditions;
import java.util.concurrent.TimeUnit;

import static org.testng.Assert.assertEquals;

import java.io.*;
import java.net.*;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.*;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;


public class ElPaisOpinionScraper {

    public static void main(String[] args) throws Exception {
       
    	WebDriver driver = new ChromeDriver();
        driver.get("https://elpais.com/");
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        Assert.assertTrue(driver.getTitle().contentEquals("EL PAÍS: el periódico global"));
        WebElement element=driver.findElement(By.xpath("//button[@id='didomi-notice-agree-button']"));
        element.click();
        driver.findElement(By.xpath("//a[contains(text(),'Internacional')]/following-sibling::a")).click();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("article")));
 ;
        // Scrape first 5 articles
        List<WebElement> articles = driver.findElements(By.cssSelector("article"));
        int count = Math.min(3, articles.size());
        System.out.println(count);
        List<String> articleUrls = new ArrayList<>();
        List<String> spanishTitles = new ArrayList<>();
        List<String> englishTitles = new ArrayList<>();
        //collect article title and URLs
        for (int i = 0; i < count; i++) {
        	WebElement article = articles.get(i);
        	String title=article.findElement(By.cssSelector("h2")).getText();
        	spanishTitles.add(title);
        	String url = article.findElement(By.xpath("//h2/a")).getAttribute("href");
        	articleUrls.add(url);
        }
       //Visit each article URL and scrape content
        for (int i = 0; i < articleUrls.size(); i++) {
            String articleUrl = articleUrls.get(i);
            driver.navigate().to(articleUrl);
           
            // Scroll
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("window.scrollBy(0, 400);");
           
           // Extract content
            WebElement articleContent=driver.findElement(By.xpath("//*[@id='main-content']/header/div/h2"));
            String content = articleContent.getText();
            System.out.println("Title: " + spanishTitles.get(i));
            System.out.println("Content: " + content);

            // Download cover image if available
            try {
                WebElement img = driver.findElement(By.xpath("//*[@id='main-content']/header/div[2]/figure/span/img"));
                String imgUrl = img.getAttribute("src");
                System.out.println("img url: " + imgUrl);
                downloadImage(imgUrl, "cover_image_" + i + ".jpg");
                System.out.println("Image Name: cover_image_" + i + ".jpg");
            } catch (NoSuchElementException e) {
                System.out.println("No image exist");
            }

            // Return to opinion section
            WebElement OpinionPage = driver.findElement(By.xpath("//a[@href='/opinion/']"));
            OpinionPage.click();
            js.executeScript("window.scrollBy(0, 400);");
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("article")));
        }

        // Translate titles
        for (String title : spanishTitles) {
            String translated = translateText(title, "es", "en");
            englishTitles.add(translated);
            System.out.println("Translated Title: " + translated);
        }
//        englishTitles.add("English majestic");
//        englishTitles.add("terracoat English");
//        englishTitles.add("sample majestic");
        // Analyze repeated words
        Map<String, Integer> wordCount = new HashMap<>();
        for (String header : englishTitles) {
            String[] words = header.toLowerCase().replaceAll("[^a-z ]", "").split("\\s+");
            for (String word : words) {
                if (word.length() > 2) { // Ignore very short words
                    wordCount.put(word, wordCount.getOrDefault(word, 0) + 1);
                }
            }
        }
        System.out.println("Repeated words (more than twice):");
        for (Map.Entry<String, Integer> entry : wordCount.entrySet()) {
            if (entry.getValue() > 2) {
                System.out.println(entry.getKey() + ": " + entry.getValue());
            }
        }
        driver.quit();
    	}

    // Download image from URL

	private static void downloadImage(String url, String fileName) throws IOException, InterruptedException {
	    HttpClient client = HttpClient.newHttpClient();
	    HttpRequest request = HttpRequest.newBuilder()
	            .uri(URI.create(url))
	            .build();
	    HttpResponse<byte[]> response = client.send(request, HttpResponse.BodyHandlers.ofByteArray());

	    if (response.statusCode() == 200) {
	        Path path = Paths.get(fileName);
	        java.nio.file.Files.write(path, response.body());
	        System.out.println("Image downloaded: " + fileName);
	    } else {
	        System.out.println("Failed to download image: HTTP " + response.statusCode());
	    }
    }
 
    // Translate text using Google Translate API
    private static String translateText(String text, String sourceLang, String targetLang) throws IOException, InterruptedException {

    	//Build the JSON request body
    	JSONObject body=new JSONObject();
        body.put("from", sourceLang);
        body.put("to", targetLang);
        body.put("text", text);
        
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create("https://rapid-translate-multi-traduction.p.rapidapi.com/t"))
            .header("content-type", "application/json")
            .header("X-RapidAPI-Key", "3011e7f4f2msh99374f7dfcf6bacp145bb1jsn5764cab49f78")
            .header("X-RapidAPI-Host", "rapid-translate-multi-traduction.p.rapidapi.com")
            .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
            .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        System.out.println("Response Body: " + response.body());
        
        if (response.statusCode() == 200) {
            JSONObject json = new JSONObject(response.body());
            // The translated text is in the "result" field
            return json.getString("result");
        } else {
            throw new RuntimeException("Translation failed: HTTP " + response.statusCode() + " - " + response.body());
        }

    }
}

