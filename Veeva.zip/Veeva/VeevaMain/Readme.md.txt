Veeva Hybrid Automation Framework

Table of Contents

1.Project Overview
2.Features
3.Technology Stack
4.Prerequisites
5.Project Structure
6.Installation & Setup
7.Running Tests
8.Test Reporting
9.Adding New Tests
10.Configuration
11.Troubleshooting
12.Contact


1. Project Overview
This project is an automated testing framework built using Selenium WebDriver, Java, Cucumber, TestNG and Maven. It is designed to automate web application testing with behavior-driven development (BDD) principles.

2. Features

BDD test scenarios using Cucumber
Cross-browser testing with Selenium WebDriver
Maven for build and dependency management
Page Object Model (POM) design pattern
Detailed test reports
Easy configuration and scalability


3. Technology Stack

Java (JDK 8 or above)
Selenium v4
Cucumber v7
Maven
TestNG 
Extent Reports (or other reporting tools like spark, Allure)
Log4j (for logging)
Jenkins(for CI/CD)

4. Prerequisites

Java JDK installed and configured in PATH
Maven installed and configured in PATH
IDE (e.g., IntelliJ IDEA, Eclipse)
Git (optional, for version control)

5. Project Structure
Code VeevaMain/
│
├── src/
│   ├── main/
│   │   └── java/
│   │   |   └── config/
│   │   |   └── pageobjects/
│   │   |   └── utils/
│   │   └── resources/
│   └── test/
│       └── java/
│       |    └── stepdefinitions/
│       |    └── runners/
│       └── resources/  
│            └── features/     
│      
├── pom.xml
├── README.md
└── test-output/


pageobjects/: Page Object Model classes
utils/: Utility/helper classes
stepdefinitions/: Cucumber step definition files
runners/: Test runner classes
features/: Cucumber feature files


6. Installation & Setup

Install Java latest version Java 11 LTS, 17 or higher
Set the JAVAPATH in the system variables
Import the project file in any available IDE's - Eclipse, IntelliJ, Visual Code
Refresh and build the pom.xml file
Download Cucumber and TestNG plugins from Marketplace.

7. Running Tests

Run specific feature file
Update the runner class to point to the desired feature file.


8. Test Reporting

Test reports are generated in the /test-output directory.
For Extent Reports or other custom reports, refer to the configuration in the pom.xml and runner classes.


9. Adding New Tests

Create a new .feature file in the features/ directory.
Define scenarios using Gherkin syntax.
Implement step definitions in the stepdefinitions/ package.
Add or update page objects as needed.


10. Configuration

Browser selection, base URL, and other settings can be managed in a configuration file (e.g., config.properties) or as Maven profiles.
Update pom.xml for dependency management.

11. Troubleshooting

Ensure all dependencies are installed (mvn clean install).
Check browser driver compatibility with your browser version.
Review logs in the console or log files for errors.

12. Contact
For questions or support, contact Ankit Sharma at ankitsharma210289@google.com