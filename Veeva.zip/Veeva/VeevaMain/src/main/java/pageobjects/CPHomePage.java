package pageobjects;


import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import utils.Jacket;
import utils.FileUtil;

public class CPHomePage {
	WebDriver driver;

    public CPHomePage(WebDriver driver) {
        this.driver = driver;
    }
    By declarationpop = By.xpath("//*[@id='onetrust-banner-sdk']/div/div/div/div[2]/div/button[contains(text(),'I Accept')]");
    By presaleticketpop=By.xpath("//div[contains(text(),'x')]");
    By shopMenu = By.xpath("//span[contains(text(),'Team')]/parent::a/parent::li/following-sibling::li/a/span[contains(text(),'Shop')]");
    By mensMenu = By.xpath("//span[contains(text(),'Shop')]/parent::a/parent::li/nav/ul/li[2]/a");
    By FatherDayPopup = By.xpath("//div/button/i[@class='icon icon-close-alt']");
    By YourSelections = By.xpath("//h2[contains(text(),'Your Selections')]");
    By JacketsRadioButton= By.xpath("//a/span[contains(text(),'Jackets')]");
    By AllJackets= By.xpath("//div[@class='product-card row']");
    By AllTitles=By.xpath("//div[@class='product-card-title']");
    By AllPrices=By.xpath("//div[@class='prices']");
    By AllTopSellerMessage=By.xpath("//span[@class='top-seller-vibrancy-message']");
    

    public void goToMensShop() {
    	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
    	driver.findElement(presaleticketpop).click();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(shopMenu));
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
        actions.moveToElement(driver.findElement(mensMenu));
        actions.click().build().perform();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(4)); 
        Object[] windowHandles=driver.getWindowHandles().toArray();
        driver.switchTo().window((String) windowHandles[1]);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(4)); 
        WebElement elementToClick = driver.findElement(FatherDayPopup);
        JavascriptExecutor executor = (JavascriptExecutor) driver;
        executor.executeScript("arguments[0].click();", elementToClick);
        driver.switchTo().window(driver.getWindowHandle());
        WebElement jacket=driver.findElement(JacketsRadioButton);
        new Actions(driver).scrollToElement(jacket).perform();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
        jacket.click();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
        List<Jacket> jackets = new ArrayList<>();
        List<WebElement> jacketElements = driver.findElements(AllJackets);
        for (WebElement jacketEl : jacketElements) {
        	List<WebElement> titleElements = jacketEl.findElements(AllTitles);
        	List<String> titles =new ArrayList<>();
        	for(WebElement titleEl : titleElements) {
        		titles.add(titleEl.getText());
        	}
        	List<WebElement> priceElements = jacketEl.findElements(AllPrices);
        	List<String> prices =new ArrayList<>();
        	for(WebElement priceEl : priceElements) {
        		prices.add(priceEl.getText());
        	}
        	String topSellerMsg = "";
        	List<WebElement> topSeller = jacketEl.findElements(AllTopSellerMessage);
        		if (!topSeller.isEmpty()) {
        			topSellerMsg = topSeller.get(0).getText();
        		}
        	jackets.add(new Jacket(titles, prices, topSellerMsg));
        }
        String filePath = "target/jacket_details.txt";
        FileUtil.writeJacketsToFile(jackets, filePath);
 
}
	
}
