package pageobjects;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;



public class CPMenuItemPage {
	WebDriver driver;

    public CPMenuItemPage(WebDriver driver) {
        this.driver = driver;
    }
    By declarationpop = By.xpath("//*[@id='onetrust-banner-sdk']/div/div/div/div[2]/div/button[contains(text(),'I Accept')]");
    By presaleticketpop=By.xpath("//div[contains(text(),'x')]");   
    By kebabMenu = By.xpath("//li/a/span[contains(text(),'...')]");
    By NewsAndFeaturesMenu = By.xpath("//a/span[contains(text(),'...')]/parent::a/parent::li/nav/ul/li[2]/a");
    By AllVideoFeeds =By.xpath("//h3[contains(text(),'VIDEOS')]/parent::div/following-sibling::div/div/ul/li");
    By VideoHeader= By.xpath("//h3[contains(text(),'VIDEOS')]");
    By days= By.xpath("//h3[contains(text(),'VIDEOS')]/parent::div/following-sibling::div/div/ul/li/div/div/div[2]/div[3]/div/time/span");
    public void goToMenuItem() {
    	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
    	driver.findElement(presaleticketpop).click();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(kebabMenu));
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
        actions.moveToElement(driver.findElement(NewsAndFeaturesMenu));
        actions.click().build().perform();    
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
     // Locate all video feed elements
        WebElement videos=driver.findElement(VideoHeader);
        new Actions(driver).scrollToElement(videos).perform();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
        List<WebElement> videoFeeds = driver.findElements(AllVideoFeeds);
        int totalVideos = videoFeeds.size();
        System.out.println("Total video feeds: " + totalVideos);
        int videosAtLeast3d = 0;

        for (WebElement feed : videoFeeds) {
        	
            // Locate the age label inside each video feed
            WebElement ageElement = feed.findElement(days);
            String ageText = ageElement.getText().trim();

            // Check if age is in days and >= 3
            if (ageText.endsWith("d")) {
                try {
                    int days = Integer.parseInt(ageText.replace("d", ""));
                    if (days >= 3) {
                        videosAtLeast3d++;
                    }
                } catch (NumberFormatException e) {
                    // Handle cases where ageText is not a number
                }
            }
        }
        System.out.println("Video feeds >= 3d: " + videosAtLeast3d);
    }
}
