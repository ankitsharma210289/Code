package pageobjects;

	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.support.PageFactory;

	public class PageObjectManager {
			public CPHomePage homepage;
			public CPMenuItemPage warriorshoppage;
			
			public PageObjectManager(WebDriver driver) {
				homepage = new CPHomePage(driver);
				warriorshoppage = new CPMenuItemPage(driver);
				
				//Centralized Initialization
				PageFactory.initElements(driver, homepage);
				PageFactory.initElements(driver, warriorshoppage);
			}
	}

