package utils;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class FileUtil {
    public static void writeJacketsToFile(List<Jacket> jackets, String filePath) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            writer.write("Title | Price | Top Seller Message");
            writer.newLine();
            for (Jacket jacket : jackets) {
                writer.write(jacket.getTitle() + " | " + jacket.getPrice() + " | " + jacket.getTopSellerMsg());
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
