package utils;

import java.util.List;

public class Jacket {
    private List<String> title;
    private List<String> price;
    private String topSellerMsg;

    public Jacket(List<String> titles, List<String> prices, String topSellerMsg) {
        this.title = titles;
        this.price = prices;
        this.topSellerMsg = topSellerMsg;
    }

    public List<String> getTitle() { return title; }
    public List<String> getPrice() { return price; }
    public String getTopSellerMsg() { return topSellerMsg; }
}
