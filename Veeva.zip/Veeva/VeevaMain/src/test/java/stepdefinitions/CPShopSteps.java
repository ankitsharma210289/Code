package stepdefinitions;
import io.cucumber.java.en.*;
import org.openqa.selenium.WebDriver;
import pageobjects.CPHomePage;
import utils.DriverFactory;
import java.util.Properties;
import config.ConfigReader;

public class CPShopSteps {
    WebDriver driver;
    CPHomePage cpHomePage;
    Properties prop;

    @Given("I am on the CP home page")
    public void i_am_on_cp_home_page() {
        prop = ConfigReader.initProperties();
        driver = DriverFactory.initDriver(prop.getProperty("browser"));
        driver.get(prop.getProperty("cp.url"));
        cpHomePage = new CPHomePage(driver);
    }

    @When("I navigate to the Shop Menu and select Men's")
    public void i_navigate_to_shop_menu_and_select_mens() {
        cpHomePage.goToMensShop();
    }

    @And("I find all Jackets and store their details")
    public void i_find_all_jackets_and_store_details() {
    	 // Implement logic to find jackets, store Title, Price, Top Seller message
         // Write to a text file
    }

    @Then("I attach the details file to the report")
    public void i_attach_details_file_to_report() {
    	// Implement logic to attach file to report
    }
}