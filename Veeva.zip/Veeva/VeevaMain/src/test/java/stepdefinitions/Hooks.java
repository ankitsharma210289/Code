package stepdefinitions;


import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Hooks {
	//WebDriver driver=new WebDriver;
	
	@Before
    public void setUp() {
        //driver = new ChromeDriver();    
    }

    @After
    public void tearDown() {
       // driver.closeBrowser();
    }
}
