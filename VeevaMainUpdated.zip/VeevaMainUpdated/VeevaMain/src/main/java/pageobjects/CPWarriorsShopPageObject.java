package pageobjects;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utils.FileUtil;

import utils.CommonFunctions;
import utils.DriverFactory;
import utils.Jacket;

public class CPWarriorsShopPageObject extends CommonFunctions{
	private WebDriverWait wait;
	WebDriver driver=DriverFactory.getDriver();
	
	public CPWarriorsShopPageObject(WebDriver driver) {

		super(driver);
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//div/button/i[@class='icon icon-close-alt']")
	private WebElement WarriorsPagePopUp;
	
	@FindBy(xpath="//a/span[contains(text(),'Tailgating')]")
	private WebElement JacketsRadioButton;

    @FindBy(xpath ="//div[@class='column']")
    private List<WebElement> jacketElementsContainers;

    @FindBy(xpath = "//div[@class='grid-paginator']/div/div/div/div/ul[@class='pagination-list-container']/li[@class='next-page']/a")
    private WebElement nextPageButton;
    
    private final By titleLocator = By.xpath("//div[@class='product-card-title']");
    private final By priceLocator = By.xpath("//div[@class='prices']");
    private final By topSellerMessageLocator = By.xpath("//span[@class='top-seller-vibrancy-message']");

	
	public void WarriorsPagePopUpClick() throws InterruptedException{
		implicitWait();
		switchToNewWindow();
		clickWebElementJavaScriptExecutor(WarriorsPagePopUp);
	}
	
	public void SelectJacketRadioButton() throws InterruptedException{
		scrollToElement(JacketsRadioButton);
		JacketsRadioButton.click();
	}
	
	public void StoreDetailsTextFile() throws InterruptedException{

        List<Jacket> allJackets = getAllJacketDetails();
        String filePath = "target/jacket_details.txt";
        FileUtil.writeJacketsToFile(allJackets, filePath);

	}
	
	private List<String> extractTextsFromWebElements(List<WebElement> elements) {
	        List<String> texts = new ArrayList<>();
	        for (WebElement el : elements) {
	            texts.add(el.getText());
	        }
	        return texts;
	}
	
	private boolean isNextPageButtonPresentAndClickable() {
	        try {
	            // Use an explicit wait to check for the presence and clickability
	            //wait.until(ExpectedConditions.elementToBeClickable(nextPageButton));
	            return nextPageButton.isDisplayed() && nextPageButton.isEnabled();
	        } catch (org.openqa.selenium.TimeoutException | org.openqa.selenium.NoSuchElementException e) {
	            // If element is not found or not clickable within the wait time
	            return false;
	        }
	    }

	
	 public List<Jacket> getAllJacketDetails() {
	        List<Jacket> allJackets = new ArrayList<>();
	        boolean hasNextPage;

	        do {
	            // Wait for the jacket containers to be visible on the current page
	            // This is crucial, especially after navigating to a new page
	            //wait.until(ExpectedConditions.visibilityOfAllElements(jacketElementsContainers));

	            // Iterate through the jacket elements on the current page
	            for (WebElement jacketEl : jacketElementsContainers) {
	                // Extract titles
	                List<WebElement> titleElements = jacketEl.findElements(titleLocator);
	                List<String> titles = extractTextsFromWebElements(titleElements);

	                // Extract prices
	                List<WebElement> priceElements = jacketEl.findElements(priceLocator);
	                List<String> prices = extractTextsFromWebElements(priceElements);

	                // Extract top seller message
	                String topSellerMsg = "";
	                List<WebElement> topSeller = jacketEl.findElements(topSellerMessageLocator);
	                if (!topSeller.isEmpty()) {
	                    topSellerMsg = topSeller.get(0).getText();
	                }

	                allJackets.add(new Jacket(titles, prices, topSellerMsg));
	            }

	            // Check if there's a next page button and if it's clickable
	            hasNextPage = isNextPageButtonPresentAndClickable();

	            if (hasNextPage) {
	                // Store the current page's URL or an element that will become stale
	                // to wait for the next page to load correctly.
	                String currentPageUrl = driver.getCurrentUrl(); // Or a specific element like firstJacketTitle
	                WebElement elementToWaitUntilStale = jacketElementsContainers.get(0).findElement(titleLocator); // Use a reliable element

	                try {
	                    nextPageButton.click();
	                    // Wait for the URL to change OR for a known element to become stale (indicating page navigation)
	                    // Then re-initialize PageFactory elements for the new page
	                   // wait.until(ExpectedConditions.or(
	                            //ExpectedConditions.not(ExpectedConditions.urlToBe(currentPageUrl)),
	                            //ExpectedConditions.stalenessOf(elementToWaitUntilStale) // Wait for old elements to disappear
	                   // ));
	                    // Re-initialize elements after navigation
	                    PageFactory.initElements(driver, this);
	                } catch (org.openqa.selenium.StaleElementReferenceException e) {
	                    System.out.println("StaleElementReferenceException caught, re-initializing elements.");
	                    // This can happen if the button itself becomes stale right after click
	                    // Re-initialize and try again for the next loop iteration's checks
	                    PageFactory.initElements(driver, this);
	                    // Re-evaluate hasNextPage after re-initialization if necessary for the loop condition
	                    hasNextPage = isNextPageButtonPresentAndClickable(); // Re-check
	                } catch (Exception e) {
	                    System.err.println("Error clicking next page button or waiting for new page: " + e.getMessage());
	                    hasNextPage = false; // Stop if there's an unexpected error
	                }
	            }

	        } while (hasNextPage); // Continue as long as there's a next page button to click

	        return allJackets;
	    }


	

}
