package pageobjects;

	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.support.PageFactory;

	public class PageObjectManager {
		    private WebDriver driver;
		    private CPHomePageObject homePage;
		    private CPMenuItemPageObject menuItemPage;
			
			public PageObjectManager(WebDriver driver) {
				this.driver=driver;
			}	
			//Centralized Initialization
			public CPHomePageObject getHomePage() {
//				homePage=new CPHomePageObject();
				PageFactory.initElements(driver, homePage);
				return homePage;
			}
			
			public CPMenuItemPageObject getMenuItemPage() {
				menuItemPage=new CPMenuItemPageObject();
				PageFactory.initElements(driver, menuItemPage);
				return menuItemPage;
			}
			
			
	}

