package utils;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CommonFunctions {
	protected WebDriver driver;
	//protected static ThreadLocal<WebDriver> threadLocalDriver =new ThreadLocal<>();
	public CommonFunctions(WebDriver driver) {
		this.driver=driver;
	}
	
		
		public void setpageloadtimeout() 
		{
			driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
		}

		/*Clicking the webelement*/
		public void clickWebElement(WebElement element) {
			element.click();
		}
		/*Clicking the webelement via JavaScriptExecutor*/
		public void clickWebElementJavaScriptExecutor(WebElement element) {
		JavascriptExecutor executor = (JavascriptExecutor) driver;
        executor.executeScript("arguments[0].click();", element);
		}
		/*Entering values using sendkeys*/
		public void sendKeysWebElement(WebElement element, String val) throws InterruptedException {
			element.sendKeys(val);
		}
		/*Perform double click using action class*/
		public void doubleClickAction(WebElement element) throws InterruptedException {
			Actions action = new Actions(driver);
			action.moveToElement(element).doubleClick().build().perform();
		}

		/*Waiting for element to be clickable*/
		public void explicitWaitUntilElementIsClickable(WebElement element) {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			wait.until(ExpectedConditions.elementToBeClickable(element));
		}
		
		/*Perform mouse hover click*/
		public void mouseHoverClickAction(WebElement elementA,WebElement elementB ) throws InterruptedException {
			Actions actions = new Actions(driver);
			actions.moveToElement(elementA);
			actions.moveToElement(elementB).click().build().perform();
		}

		/*Waiting for all elements to be loaded */
		public void implicitWait() {
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

		}
		/*Switch to new window*/
		public void switchToNewWindow() {
			Object[] windowHandles=driver.getWindowHandles().toArray();
	        driver.switchTo().window((String) windowHandles[1]);
		}
		/*Switch to new window*/
		public void scrollToElement(WebElement element) {
			new Actions(driver).scrollToElement(element).perform();
		}
		/*Waiting for page to be loaded*/
		public void pageLoadTimeout() {
			driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
		}

		/*Waiting for fix stale element*/
		public void fluentWait() {
			Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(30))
					.pollingEvery(Duration.ofSeconds(5)).ignoring(StaleElementReferenceException.class);

		}
	

}
