package utils;

import java.util.List;

public class Jacket {
    private List<String> titles;
    private List<String> prices;
    private String topSellerMsg;

    public Jacket(List<String> titles, List<String> prices, String topSellerMsg) {
        this.titles = titles;
        this.prices = prices;
        this.topSellerMsg = topSellerMsg;
    }

    public List<String> getTitle() 
    { 
    	return titles; 
    }
    public List<String> getPrice() 
    { 
    	return prices; 
    }
    public String getTopSellerMsg() 
    { 
    	return topSellerMsg; 
    }
    
    @Override
    public String toString() {
        return "Jacket{" +
               "titles=" + titles +
               ", prices=" + prices +
               ", topSellerMessage='" + topSellerMsg + '\'' +
               '}';
    }
}
