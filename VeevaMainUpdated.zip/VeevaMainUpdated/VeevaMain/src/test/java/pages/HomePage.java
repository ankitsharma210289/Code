package pages;

import org.openqa.selenium.WebDriver;

import config.ConfigReader;
import pageobjects.CPHomePageObject;
import utils.DriverFactory;

public class HomePage{
	private CPHomePageObject cpHomePageObject;
	WebDriver driver=DriverFactory.getDriver(); //Always get the driver from DriverFactory 
	
	public HomePage(WebDriver driver) {
		this.cpHomePageObject=new CPHomePageObject(driver);
	}
	
	public void NavigateToHomePage() {
		 String url=ConfigReader.getProperty("cp.url"); // Fetch the url from config.properties using ConfigReader
	      driver.get(url);
	}
	
	public void HomePageNavigationForSelection() throws InterruptedException {
		cpHomePageObject.clickpresaleticketPopUp();
		cpHomePageObject.mouseHovershopMenuToClickMensSection();	
	}
	
}
