package pages;

import org.openqa.selenium.WebDriver;

import config.ConfigReader;
import pageobjects.CPWarriorsShopPageObject;
import utils.DriverFactory;

public class WarriorsPage {
	private CPWarriorsShopPageObject cpWarriorsShopPageObject;
	WebDriver driver=DriverFactory.getDriver(); //Always get the driver from DriverFactory 
	
	public WarriorsPage(WebDriver driver) {
		this.cpWarriorsShopPageObject=new CPWarriorsShopPageObject(driver);
	}
	
	public void WarriorPagePopUpHandling() throws InterruptedException {
		cpWarriorsShopPageObject.WarriorsPagePopUpClick();
	}
	
	public void WarriorPageNavigationForSelectionOfJacket() throws InterruptedException {
		cpWarriorsShopPageObject.SelectJacketRadioButton();	
	}
	
	public void StoreJacketDetails() throws InterruptedException {
		cpWarriorsShopPageObject.StoreDetailsTextFile();
	}
	
}
