package stepdefinitions;
import io.cucumber.java.en.*;
import org.openqa.selenium.WebDriver;
import pageobjects.CPHomePageObject;
import pages.HomePage;
import pages.WarriorsPage;
import utils.DriverFactory;
import config.ConfigReader;

public class CPHomePageSteps {
    
	private HomePage homePage;
    
    public CPHomePageSteps() {
    	WebDriver driver=DriverFactory.getDriver(); //Always get the driver from DriverFactory 
    	this.homePage=new HomePage(driver);
    }
      
    @Given("I am on the CP home page")
    public void i_am_on_cp_home_page() {
        homePage.NavigateToHomePage();
    }

    @When("I navigate to the Shop Menu and select Men's")
    public void i_navigate_to_shop_menu_and_select_mens() throws InterruptedException {
        homePage.HomePageNavigationForSelection();
    }

}