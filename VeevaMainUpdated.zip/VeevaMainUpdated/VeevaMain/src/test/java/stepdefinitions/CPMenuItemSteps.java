package stepdefinitions;

import io.cucumber.java.en.*;
import org.openqa.selenium.WebDriver;
import pageobjects.CPMenuItemPageObject;
import utils.DriverFactory;
import config.ConfigReader;

public class CPMenuItemSteps {
    
    CPMenuItemPageObject cpMenuItemPage;
    
    WebDriver driver=DriverFactory.getDriver(); //Always get the driver form DriverFactory

    @Given("I am on the CP1 home page")
    public void i_am_on_cp_home_page() {
    	  String url=ConfigReader.getProperty("cp.url"); // Fetch the url from config.properties using ConfigReader
          driver.get(url);
          cpMenuItemPage=new CPMenuItemPageObject();
    }

    @When("I navigate to the Shop Menu and click on kebab menu")
    public void i_navigate_to_the_shop_menu_and_click_on_kebab_menu() {
    	cpMenuItemPage.goToMenuItem();
    }

    @And("I count all Video feeds")
    public void I_count_all_video_feeds() {
        // Implement logic to count all video feeds
        // Write to a text file
    }

    @Then("I count the video feeds which are 3 days and less older only")
    public void I_count_the_video_feeds_which_are_3_days_older_only() {
        // Implement logic to count all video feeds which are only 3 days and less old
    }
}
