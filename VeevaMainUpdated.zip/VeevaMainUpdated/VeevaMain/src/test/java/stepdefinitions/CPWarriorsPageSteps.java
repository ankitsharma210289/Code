package stepdefinitions;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.WarriorsPage;
import utils.DriverFactory;

public class CPWarriorsPageSteps {

	private WarriorsPage warriorsPage;
    
    public CPWarriorsPageSteps() {
    	WebDriver driver=DriverFactory.getDriver(); //Always get the driver from DriverFactory 
    	this.warriorsPage=new WarriorsPage(driver);
    }
    
    @And("I am on the warriors shop page")
    public void i_am_on_the_warriers_shop_page() throws InterruptedException {
    	warriorsPage.WarriorPagePopUpHandling();
    }

    @And("I click on the jacket radio button to filter the main list")
    public void i_click_on_the_jacket_radio_button_to_filter_the_main_list() throws InterruptedException {
    	warriorsPage.WarriorPageNavigationForSelectionOfJacket();
    }

    @And("I store the Jacket details in a text file format")
    public void i_store_the_jacket_details_in_a_text_file_format() throws InterruptedException {      
    	warriorsPage.StoreJacketDetails();
    }

    @Then("I attach the details file to the report")
    public void i_attach_the_details_file_to_the_report() {
    
    }
}
