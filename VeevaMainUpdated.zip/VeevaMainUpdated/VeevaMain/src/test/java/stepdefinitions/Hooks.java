package stepdefinitions;

import config.ConfigReader;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import utils.DriverFactory;

public class Hooks {
	
	@Before
    public void setUp() {
		//Read browser from config.properties using ConfigReader
	   String browser=ConfigReader.getProperty("browser");
       DriverFactory.initDriver(browser);
    }

    @After
    public void tearDown() {     
    	//DriverFactory.quitDriver();
    }
}
